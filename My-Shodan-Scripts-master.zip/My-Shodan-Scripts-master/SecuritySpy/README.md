Security Spy Cameras 

No Auth and some times they are small cams.

Generally have multiple cams this script checks for 3 cams on each ip.

