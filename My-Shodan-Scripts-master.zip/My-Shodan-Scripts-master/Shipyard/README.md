Shipyard
-----

Shipyard is a Docker Web Management System

it has default username and password of admin:shipyard

This will find weak systems that should be secured.