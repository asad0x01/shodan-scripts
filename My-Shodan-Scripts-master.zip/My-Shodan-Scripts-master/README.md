# My-Shodan-Scripts
Collection of Scripts for shodan searching stuff.

Written using Python3 as a heads up not sure if works on python2

USE AT YOUR OWN RISK AND WHAT YOU DO WITH THIS IS UP TO YOU NOT ME!
