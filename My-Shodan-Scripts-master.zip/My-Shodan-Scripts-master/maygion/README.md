maygion cameras.

Basic as hell and default user and pass is admin:admin.

This generates a playlist so ensure you have ffmpeg installed!