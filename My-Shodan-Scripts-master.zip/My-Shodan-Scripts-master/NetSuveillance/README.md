Shodan Dork: title:"NETSurveillance WEB"

Default user: admin and password is blank.