Generates a M3U playlist file full of open IP cams from around the world.

* Requires python3
